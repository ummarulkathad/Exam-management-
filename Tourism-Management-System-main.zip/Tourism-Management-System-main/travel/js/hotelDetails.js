$(document).ready(function() {
	
	//delete account
	
	
	
}); //document ready